#pragma once
#include "platform/gpu_select.h"
#include "platform/hwinfo.h"
#include <string>
#include <vector>

struct LaunchAction {
    enum Type { None, LaunchBenchmark, LaunchDemo };
    Type type;
    std::vector<std::string> args;

    LaunchAction() : type(None) {}
};

struct LauncherState {
    // Mode: 0 = benchmark, 1 = demo
    int mode;

    // Common parameters
    int gpu_index;          // -1 = default
    int backend;            // 0=auto, 1=gl2, 2=gl3, 3=gl4, 4=gles
    int width, height;
    int render_width, render_height;
    bool use_render_res;
    bool headless;
    bool debug;
    bool verbose;

    // Benchmark-specific
    int preset;             // 0-4 (Light..Extreme)
    int output_format;      // 0=text, 1=csv, 2=json
    int timing_mode;        // 0=sync, 1=gpu
    char output_file[256];
    char test_filter[512];
    int stress_seconds;

    // Demo-specific
    int tier;               // 0=auto, 1-4
    int duration;

    // Detected hardware (populated once at init)
    HWInfo hw_info;
    std::vector<GPUDevice> gpus;

    LauncherState();

    // Build the command preview string
    std::string commandPreview() const;
};

// Draw the launcher UI. Returns a LaunchAction when the user clicks Launch.
LaunchAction drawLauncherUI(LauncherState& state);
