#pragma once
#include "demo/demo_pipeline.h"
#include <memory>
#include <vector>

struct DemoTierConfig;
struct DemoDebugOverrides;
struct TierResourceView;
class DemoRenderPass;

// Build render pipeline from pass vector using resource dependency
// topological sort. Passes declare reads/writes via resourceDecls(),
// builder determines execution order automatically.
void buildPipeline(DemoPipeline& pipeline,
                   const std::vector<std::unique_ptr<DemoRenderPass>>& passes,
                   const DemoTierConfig& config,
                   const DemoDebugOverrides& debug,
                   const TierResourceView& res,
                   int viewport_w, int viewport_h);
