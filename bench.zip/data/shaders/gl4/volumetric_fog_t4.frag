#version 430
in vec2 v_uv;
out vec4 FragColor;

uniform sampler2D u_depth_tex;
uniform float u_near;
uniform float u_far;
uniform float u_aspect;
uniform float u_tan_half_fov;
uniform mat4 u_view_inv;
uniform float u_time;
uniform vec3 u_sun_dir;
uniform float u_fog_density;
uniform vec3 u_fog_color;
uniform int u_fog_steps;

#pragma include "noise_lib.glsl"

float linearizeDepth(float d) {
    return u_near * u_far / (u_far - d * (u_far - u_near));
}

// Henyey-Greenstein phase function for anisotropic scattering (pbrt v3 reference)
float henyeyGreenstein(float cosTheta, float g) {
    float g2 = g * g;
    float denom = 1.0 + g2 - 2.0 * g * cosTheta;
    denom = max(denom, 1e-5);
    return (1.0 - g2) / (4.0 * 3.14159265 * denom * sqrt(denom));
}

void main() {
    // Reconstruct view-space ray direction from UV
    vec2 ndc = v_uv * 2.0 - 1.0;
    vec3 view_dir = vec3(
        ndc.x * u_tan_half_fov * u_aspect,
        ndc.y * u_tan_half_fov,
        -1.0
    );

    // Transform to world-space ray
    vec3 ray_dir = normalize((u_view_inv * vec4(view_dir, 0.0)).xyz);
    vec3 ray_origin = (u_view_inv * vec4(0.0, 0.0, 0.0, 1.0)).xyz;

    // Scene depth at this pixel
    float depth_sample = texture(u_depth_tex, v_uv).r;
    float scene_depth = linearizeDepth(depth_sample);

    // Dithered start to reduce banding
    float dither = fract(dot(gl_FragCoord.xy, vec2(0.75487766, 0.56984029)));

    // Raymarch parameters - use uniform step count (64 for T4)
    int steps = u_fog_steps > 0 ? u_fog_steps : 32;
    float max_dist = min(scene_depth, 30.0);
    float step_size = max_dist / float(steps);

    float t = step_size * dither;

    vec3 accumulated_fog = vec3(0.0);
    float accumulated_density = 0.0;
    float transmittance = 1.0;

    vec3 sun_dir = normalize(u_sun_dir);

    for (int i = 0; i < steps; i++) {
        if (transmittance < 0.01) break;

        vec3 sample_pos = ray_origin + ray_dir * t;

        // Height-based fog: denser near ground (y = -1 is ground level)
        float height_fog = exp(-max(sample_pos.y + 1.0, 0.0) * 0.8);

        // Noise-based density variation
        float noise_val = fbm3d(sample_pos * 0.4 + vec3(u_time * 0.15, -u_time * 0.1, u_time * 0.08), 3);
        float density = u_fog_density * height_fog * (0.5 + noise_val * 0.5);

        if (density > 0.001) {
            // Enhanced Henyey-Greenstein: stronger forward scattering for god rays
            float cos_angle = dot(ray_dir, sun_dir);

            // Triple-lobe phase: narrow god rays + wide scatter + backscatter
            float phase_narrow = henyeyGreenstein(cos_angle, 0.95);  // tight god ray core
            float phase_wide   = henyeyGreenstein(cos_angle, 0.5);   // broad forward scatter
            float phase_back   = henyeyGreenstein(cos_angle, -0.3);  // backscatter fill
            float phase = phase_narrow * 0.4 + phase_wide * 0.35 + phase_back * 0.25;

            // Sun light contribution through fog
            vec3 sun_light = vec3(1.0, 0.95, 0.85) * phase * 2.5;

            // Ambient fog light (hemisphere)
            vec3 ambient_fog = u_fog_color * 0.4;

            // In-scattering at this step
            vec3 in_scatter = (sun_light + ambient_fog) * density * step_size;

            // Beer's law transmittance (always correct for extinction)
            float step_transmittance = exp(-density * step_size);

            // Beer-Powder silver lining (Wrenninge 2015, Frostbite):
            // boosts in-scattering at density edges for volumetric glow effect.
            // This modulates scattering, NOT transmittance.
            float powder = 1.0 - exp(-density * step_size * 2.0);
            in_scatter *= (1.0 + powder * 0.3);

            accumulated_fog += in_scatter * transmittance;
            transmittance *= step_transmittance;
        }

        t += step_size;
    }

    accumulated_density = 1.0 - transmittance;

    FragColor = vec4(accumulated_fog, accumulated_density);
}
